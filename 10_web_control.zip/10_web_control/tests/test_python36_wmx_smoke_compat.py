import ast
import unittest
from pathlib import Path


class TestPython36WmxSmokeCompat(unittest.TestCase):
    def test_wmx_smoke_import_path_parses_as_python36(self):
        root = Path(__file__).resolve().parents[1]
        files = [
            root / "tools" / "manual_wmx_smoke.py",
            root / "backend" / "adapters" / "wmx_ethercat_adapter.py",
            root / "backend" / "adapters" / "base.py",
            root / "backend" / "dto.py",
            root / "backend" / "pdo_codec.py",
            root / "backend" / "protocol.py",
        ]

        for path in files:
            with self.subTest(path=str(path)):
                source = path.read_text(encoding="utf-8")
                ast.parse(source, filename=str(path), feature_version=(3, 6))


if __name__ == "__main__":
    unittest.main()
